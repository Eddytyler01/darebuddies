<?php

namespace App\Http\Controllers;
use App\Data;
use App\User;
use App\Answer;
use Illuminate\Support\Facades\Hash;
use App\Question;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class AdminIndex extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::where('role_id', '=', 2)->where('status', '=', 1)->orderBy('id', 'DESC')->get();

        return view('admin.index', compact('user'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        Question::create([

            'user_id' => Auth::user()->id,
            'question' => $input['question'],
        ]);

        Session::flash('insert', 'Successfully Added');

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $check = Question::findOrFail($id);

        if ($check->status == 0) 
        {
            $ch = Question::where('user_id', '=', Auth::user()->id)->where('status', '=', 1)->count();

            if ($ch >= 10) 
            {
                Session::flash('danger', "Can't active more than 10 questions!");

                return redirect()->back();
            }
            else
            {
                $check->update(['status'=>1]);

                Session::flash('insert', 'Successfully Active!');

                return redirect()->back();
            }
        }
        else
        {
            $check->update(['status'=>0]);

            Session::flash('insert', 'Successfully In-Active!');

            return redirect()->back();
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = $request->all();

        if (request()->has('google_analytics_code')) 
        {
            $this->validate($request, [
                'google_analytics_code' => 'required',
            ]);

            Data::findOrFail($id)->update([

                'google_code' => $input['google_analytics_code'],

            ]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('header_ad')) 
        {

            Data::findOrFail($id)->update([

                'header_ad' => $input['header_ad'],
                'footer_ad' => $input['footer_ad'],

            ]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('site_name')) 
        {
            $this->validate($request, [
                'site_name' => 'required',
                'site_title' => 'required',
                'site_description' => 'required',
                'site_keywords' => 'required',
                'og_image' => 'image|mimes:jpeg,png,jpg|max:2000',
            ]);

            $data = Data::findOrFail($id);

            if($file = $request->file('og_image'))
            {
                $name = rand() . '.' . $file->getClientOriginalExtension();

                $file->move('images', $name);
            }
            else
            {
                $name = $data->og_image;
            }
        
            

            $data->update([

                'site_name' => $input['site_name'],
                'site_title' => $input['site_title'],
                'site_description' => $input['site_description'],
                'site_keywords' => $input['site_keywords'],
                'og_image' => $name,
                'verification' => $input['verification'],
                'footer' => $input['footer'],

            ]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('question')) 
        {
            Question::findOrFail($id)->update(['question'=>$input['question']]);

            Session::flash('insert', 'Successfully Edited!');

            return redirect()->back();
        }
        elseif (request()->has('about_us')) 
        {
            $data = Data::findOrFail($id)->update(['about_us'=>$input['about_us']]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('contact_us')) 
        {
            $data = Data::findOrFail($id)->update(['contant_us'=>$input['contact_us']]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('policy')) 
        {
            $data = Data::findOrFail($id)->update(['policy'=>$input['policy']]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('tc')) 
        {
            $data = Data::findOrFail($id)->update(['tc'=>$input['tc']]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
        elseif (request()->has('photo') OR request()->has('ad_link')) 
        {
            $this->validate($request, [
                'ad_link' => 'required',
                'photo' => 'image|mimes:jpeg,png,jpg|max:2000',
            ]);

            $data = Data::findOrFail($id);

            if($file = $request->file('photo'))
            {
                $name = rand() . '.' . $file->getClientOriginalExtension();

                $file->move('images', $name);
            }
            else
            {
                $name = $data->footer_custom_ad;
            }

            $data->update([

                'footer_custom_ad' => $name,
                'footer_custom_link' => $input['ad_link'],
            ]);

            Session::flash('insert', 'Successfully Updated!');

            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);

        User::where('user_id', '=', $user->user_id)->delete();

        $user->delete();

        Answer::where('user_id', '=', $id)->delete();

        Session::flash('insert', 'Successfully Deleted!');

        return redirect()->back();
    }

    public function terms()
    {
        $data = Data::first();

        return view('admin.terms', compact('data'));
    }

    public function privacy()
    {
        $data = Data::first();

        return view('admin.privacy', compact('data'));
    }

    public function about()
    {
        $data = Data::first();

        return view('admin.about', compact('data'));
    }

    public function contact()
    {
        $data = Data::first();

        return view('admin.contact', compact('data'));
    }

    public function google()
    {
        $data = Data::first();

        return view('admin.google', compact('data'));
    }

    public function ads()
    {
        $data = Data::first();

        return view('admin.ads', compact('data'));
    }

    public function site()
    {
        $data = Data::first();

        return view('admin.site', compact('data'));
    }

    public function question()
    {
        $data = Data::first();

        $question = Question::where('user_id', '=', Auth::user()->id)->orderBy('id', 'ASC')->get();

        return view('admin.question', compact('data', 'question'));
    }

    public function custom()
    {
        $data = Data::first();

        return view('admin.custom', compact('data'));
    }

    public function changepass()
    {
        $data = Data::first();

        return view('admin.change', compact('data'));
    }

    public function changep(Request $request)
    {
        $input = $request->all();

        $this->validate($request, [
           'old_pass' => 'required|min:6',
           'new_pass' => 'required|min:6',
        ]);

        $user = Auth::user();

        $currentpass = $user->password;
        if(Hash::check($input['old_pass'], $currentpass))
        {                                  
            $obj_user = User::find($user->id);
            $obj_user->password = Hash::make($input['new_pass']);;
            $obj_user->save(); 

            Session::flash('insert', 'Successfully changed password !');
            return redirect()->back();
        }
        else
        {   
            Session::flash('nochange', 'Current password not matched!');
            return redirect()->back();
        }
    }
}
