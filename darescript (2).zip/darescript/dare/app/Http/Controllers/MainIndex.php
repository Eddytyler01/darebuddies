<?php

namespace App\Http\Controllers;
use App\Data;
use App\User;
use App\Question;
use App\Answer;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class MainIndex extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Data::first();

        if (isset($_COOKIE['userdare']))
        {
            if (isset($_COOKIE['jjdare'])) 
            {
                $user = User::where('user_id', '=', $_COOKIE['jjdare'])->where('role_id', '=', 2)->first();

                if (isset($user->status) == 0) 
                {
                    if ($user->type == 2 OR $user->type == 3) 
                    {
                        return redirect('make-question');
                    }

                    return redirect()->to('/option/'.$_COOKIE['jjdare']);
                }
                else
                {
                    return redirect()->to('/result/'.$_COOKIE['jjdare']);
                }  
            }
            else
            {
                $user = User::findOrFail($_COOKIE['jjdareuser']);

                if ($user->status == 0) 
                {
                    return redirect()->to('/quiz/'.$_COOKIE['userdare']);
                }
                else
                {
                    return redirect('/dare-board');
                }
            } 
        }

        if (isset($_COOKIE['jjdare'])) 
        {
            $user = User::where('user_id', '=', $_COOKIE['jjdare'])->where('role_id', '=', 2)->first();

            if ($user->status == 0) 
            {
                if ($user->type == 2 OR $user->type == 3) 
                {
                    return redirect('make-question');
                }

                return redirect()->to('/option/'.$_COOKIE['jjdare']);
            }
            else
            {
                return redirect()->to('/result/'.$_COOKIE['jjdare']);
            }  
        }
        else
        {
            return view('welcome', compact('data'));
        }

        
    }

    public function new()
    {
        $data = Data::first();

        return view('welcome', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $data = Data::first();

        $user = User::where('user_id', '=', $id)->where('role_id', '=', 2)->first();

        $admin = User::where('role_id', '=', 1)->first();

        $question = Question::where('user_id', '=', $admin->id)->where('status', '=', 1)->orderBy('id', 'ASC')->get();

        return view('option', compact('data', 'user', 'question'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        if (request()->has('user_id')) 
        {
            if ($input['user_id'] == '0') 
            {
                User::where('user_id', '=', $_COOKIE['jjdare'])->update(['status'=>1]);

                return redirect()->to('/result/'.$_COOKIE['jjdare']);
            }
            else
            {
                User::where('user_id', '=', $input['user_id'])->update(['status'=>1,'type'=>1]);

                return redirect()->to('/result/'.$input['user_id']);
            }            
        }
        elseif (request()->has('player')) 
        {
            setcookie('userdare', $input['id']);

            $userdata = $input['id'];

            $user = User::create([

                'role_id' => 3,
                'user_id' => $userdata,
                'name' => $input['player'],
            ]);

            setcookie('jjdareuser', $user->id);

            return redirect()->to('/quiz/'.$userdata);
        }
        elseif (request()->has('answer')) 
        {

            $checkans = Answer::where('user_id', '=', $_COOKIE['jjdareuser'])->where('ques_id', '=', $input['quesid'])->count();

            if ($checkans == 0) 
            {
                Answer::create([

                    'user_id' => $_COOKIE['jjdareuser'],
                    'ques_id' => $input['quesid'],
                    'ans_given' => $input['answer'],
                ]);
            }
            else
            {
                Answer::where('user_id', '=', $_COOKIE['jjdareuser'])->where('ques_id', '=', $input['quesid'])->update(['ans_given'=>$input['answer']]);
            }

            $data = Data::first();

            $user = User::where('user_id', '=', $_COOKIE['userdare'])->where('role_id', '=', 2)->first();

            if ($user->type == 1) 
            {
                $admin = User::where('role_id', '=', 1)->first();

                $questions = Question::where('user_id', '=', $admin->id)->where('status', '=', 1)->orderBy('id', 'ASC')->get();
            }
            else
            {
                $questions = Question::where('user_id', '=', $user->id)->where('status', '=', 1)->orderBy('id', 'ASC')->get();
            }

            if (!empty($questions)) 
            {
                $totalQ = count($questions);

                if ($input['quesno'] < $totalQ) 
                {
                    $quesno   = ((int) $input['quesno']) + 1;
                    $question = $questions[$input['quesno']];

                    $ans_given = Answer::where('user_id', '=', $_COOKIE['jjdareuser'])->where('ques_id', '=', $question->id)->first();

                    return view('quiz', compact('data', 'user', 'question', 'quesno', 'ans_given'));
                }
                else
                {
                    return redirect('/dare-board');
                }
            }
        }
        elseif (request()->has('a1')) 
        {
            $this->validate($request, [
                'question' => 'required',
                'a1' => 'required',
                'a2' => 'required',
                'a3' => 'required',
                'a4' => 'required',
                'correct' => 'required',
            ]);

            $admin = User::where('user_id', '=', $_COOKIE['jjdare'])->first();

            if ($admin->type == null) 
            {
                User::findOrFail($admin->id)->update(['type'=>2]);
            }

            Question::create([

                'user_id' => $admin->id,
                'question' => $input['question'],
                'a1' => $input['a1'],
                'a2' => $input['a2'],
                'a3' => $input['a3'],
                'a4' => $input['a4'],
                'correct' => $input['correct'],
                'status' => 1,
            ]);

            Session::flash('insert', 'Successfully Added!!');

            return redirect()->back();
        }
        elseif (request()->has('trfa')) 
        {
            $this->validate($request, [
                'question' => 'required',
                'correct' => 'required',
            ]);

            $admin = User::where('user_id', '=', $_COOKIE['jjdare'])->first();

            if ($admin->type == null) 
            {
                User::findOrFail($admin->id)->update(['type'=>3]);
            }

            Question::create([

                'user_id' => $admin->id,
                'question' => $input['question'],
                'correct' => $input['correct'],
                'status' => 1,
            ]);

            Session::flash('insert', 'Successfully Added!!');

            return redirect()->back();
        }
        else
        {
            $user_id = base64_encode(rand(1000,9999));  

            setcookie('jjdare', $user_id);

            setcookie('userdare', "");

            User::create([

                'role_id' => 2,
                'user_id' => $user_id,
                'name' => $input['name'],
            ]);

            return redirect()->to('/option/'.$user_id);

        }

    }

    public function dareboard()
    {
        $user = User::where('user_id', '=', $_COOKIE['userdare'])->where('role_id', '=', 2)->first();

        $ans = Answer::where('user_id', '=', $_COOKIE['jjdareuser'])->orderBy('id', 'ASC')->get();

        $correctans = 0;
        foreach ($ans as $dejavab) 
        {
            $que = Question::findOrFail($dejavab->ques_id);

            if ($que->correct == $dejavab->ans_given) 
            {
                ++$correctans;
            }
        }

        $admin = User::findOrFail($_COOKIE['jjdareuser'])->update(['status'=>1, 'result'=>$correctans]);

        $data = Data::first();

        $dare = User::where('user_id', '=', $_COOKIE['userdare'])->where('status', '=', 1)->where('role_id', '=', 3)->orderBy('id', 'DESC')->get();

        

        return view('userresult', compact('data', 'user', 'dare', 'ans'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Data::first();

        $user = User::where('user_id', '=', $id)->where('role_id', '=', 2)->first();

        $dare = User::where('user_id', '=', $id)->where('role_id', '=', 3)->where('status', '=', 1)->orderBy('id', 'DESC')->get();

        return view('result', compact('data', 'user', 'dare'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $chc = Crypt::decrypt($id);

        Question::findOrFail($chc)->delete();

        Session::flash('insert', 'Successfully Deleted!');

        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    public function type($id)
    {
        $make = Crypt::decrypt($id);

        $data = Data::first();

        $admin = User::where('user_id', '=', $_COOKIE['jjdare'])->first();

        $question = Question::where('user_id', '=', $admin->id)->orderBy('id', 'ASC')->get();

        if ($admin->type == null) 
        {
            return view('make', compact('make', 'data', 'question'));
        }
        else
        {
            if ($admin->type != $make) 
            {
                if ($make == 2) 
                {
                    $message = "Complete True / False Questions!";
                }
                elseif($make == 3)
                {
                    $message = "Complete Objective Questions!";                }

                Session::flash('danger', $message);

                return redirect('make-question');
            }
            else
            {
                return view('make', compact('make', 'data', 'question'));
            }
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::findOrFail($id)->delete();

        Answer::where('user_id', '=', $id)->delete();

        Session::flash('insert', 'Successfully Deleted!');

        return redirect()->back();
    }

    // public function board()
    // {
    //     $data = Data::first();

    //     $user = User::where('user_id', '=', $_COOKIE['jjdare'])->where('role_id', '=', 2)->first();

    //     $dare = User::where('user_id', '=', $_COOKIE['jjdare'])->where('role_id', '=', 3)->where('status', '=', 1)->orderBy('id', 'DESC')->get();

    //     return view('dareboard', compact('data', 'user', 'dare'));
    // }

    public function match($id)
    {
        $data = Data::first();

        $user = User::where('user_id', '=', $id)->where('role_id', '=', 2)->first();

        return view('match', compact('data', 'user', 'id'));
    }

    public function quiz($id)
    {
        $data = Data::first();

        $user = User::where('user_id', '=', $id)->where('role_id', '=', 2)->first();

        if ($user->type == 1) 
        {
            $admin = User::where('role_id', '=', 1)->first();

            $questions = Question::where('user_id', '=', $admin->id)->where('status', '=', 1)->orderBy('id', 'ASC')->get();
        }
        else
        {
            $questions = Question::where('user_id', '=', $user->id)->where('status', '=', 1)->orderBy('id', 'ASC')->get();
        }

        $question  = $questions[0];

        $ans_given = Answer::where('user_id', '=', $_COOKIE['jjdareuser'])->where('ques_id', '=', $question->id)->first();

        $quesno    = 1;

        return view('quiz', compact('data', 'user', 'question', 'quesno', 'ans_given'));
    }

    public function about()
    {
         $data = Data::first();

         return view('about', compact('data'));
    }

    public function contact()
    {
         $data = Data::first();

         return view('contact', compact('data'));
    }

    public function privacy()
    {
         $data = Data::first();

         return view('policy', compact('data'));
    }

    public function terms()
    {
         $data = Data::first();

         return view('terms', compact('data'));
    }

    public function makeq()
    {
        $data = Data::first();

        return view('make', compact('data'));
    }
}
