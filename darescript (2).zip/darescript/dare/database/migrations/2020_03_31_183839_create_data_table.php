<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data', function (Blueprint $table) {
            $table->id();
            $table->text('header_ad')->nullable();
            $table->text('footer_ad')->nullable();
            $table->string('footer_custom_ad')->nullable();
            $table->text('google_code')->nullable();
            $table->string('site_name')->nullable();
            $table->string('site_title')->nullable();
            $table->string('footer_custom_link')->nullable();
            $table->string('site_description')->nullable();
            $table->string('site_keywords')->nullable();
            $table->string('og_image')->nullable();
            $table->text('about_us')->nullable();
            $table->text('footer')->nullable();
            $table->text('contant_us')->nullable();
            $table->text('policy')->nullable();
            $table->text('tc')->nullable();
            $table->text('verification')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('data');
    }
}
