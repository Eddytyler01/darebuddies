<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}} | About Us</title>

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>About Us</h1>
        <div class="main_box">

        	@if($data->about_us == null)
        	<center><strong>No Record Found!</strong></center>
        	@else
            <?php echo $data->about_us; ?>
        	@endif
        </div>
    </div>
</div>
@stop