@extends('layouts.admin')

@section('content')
<style type="text/css">
  #mceu_44
  {
    display:none!important;
  }
</style>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>tinymce.init({ selector:'#editer',
    plugins: [
        "advlist autolink lists charmap print preview hr pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime nonbreaking save contextmenu directionality",
        "paste textcolor colorpicker"
    ],
    toolbar1: "undo redo | styleselect fontselect | fontsizeselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
    toolbar2: "link | colorpicker forecolor backcolor | preview ",

 });

</script>
	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">About-Us Page</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

		{!! Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1']]) !!}
			<div class="form-group">
				<label>About-Us Page</label>
				<textarea rows="6" id="editer" style="min-height:500px;" class="form-control @error('about_us') is-invalid @enderror" name="about_us" placeholder="Code here...">{{$data->about_us ? $data->about_us : old('about_us')}}</textarea>
				@error('about_us')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
			</div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop