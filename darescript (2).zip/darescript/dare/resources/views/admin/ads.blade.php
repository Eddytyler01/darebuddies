@extends('layouts.admin')

@section('content')

	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Ads Settings</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

		{!! Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1']]) !!}
			<div class="form-group">
				<label>Header Ad</label>
				<textarea rows="6" class="form-control @error('header_ad') is-invalid @enderror" name="header_ad" placeholder="Code here...">{{$data->header_ad ? $data->header_ad : old('header_ad')}}</textarea>
				@error('header_ad')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
			</div>
      <div class="form-group">
        <label>Footer Ad</label>
        <textarea rows="6" class="form-control @error('footer_ad') is-invalid @enderror" name="footer_ad" placeholder="Code here...">{{$data->footer_ad ? $data->footer_ad : old('footer_ad')}}</textarea>
        @error('footer_ad')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
      </div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop