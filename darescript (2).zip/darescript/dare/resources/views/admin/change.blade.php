@extends('layouts.admin')

@section('content')

	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Change Password</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

        @if(Session::has('nochange'))
            <div class="alert alert-danger">
                <strong> {{session('nochange')}}</strong>
            </div><br/>
        @endif

		{!! Form::open(['method'=>'POST', 'url'=>'changep']) !!}
			<div class="form-group">
				<label>Old Password</label>
				<input type="password" name="old_pass" class="form-control @error('old_pass') is-invalid @enderror" required="required" placeholder="Old Password">
				@error('old_pass')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
			</div>
      <div class="form-group">
        <label>New Password</label>
        <input type="password" name="new_pass" class="form-control @error('new_pass') is-invalid @enderror" required="required" placeholder="New Password">
        @error('new_pass')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="con_pass" class="form-control @error('con_pass') is-invalid @enderror" required="required" placeholder="Confirm Password">
        @error('con_pass')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
      </div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop