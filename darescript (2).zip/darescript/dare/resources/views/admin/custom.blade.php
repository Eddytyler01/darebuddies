@extends('layouts.admin')

@section('content')

	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Custom Footer Ad</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
            @else
            <div class="alert alert-info">
                <strong> Note:</strong><br/>
                <strong>Image Width:</strong> 400 pixels<br/>
                <strong>Image Height:</strong> 350 pixels
            </div><br/>
        @endif

		{!! Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1'], 'files'=>true]) !!}
			<div class="form-group">
        <label>Select File</label>
        <input type="file" name="photo" class="form-control @error('photo') is-invalid @enderror">
				@error('photo')
          <span class="invalid-feedback" role="alert">
              <strong>{{ $message }}</strong>
          </span>
      @enderror
			</div>
      @if($data->footer_custom_ad != null)
      <div class="form-group">
        <img src="{{url('/')}}/images/{{$data->footer_custom_ad}}" class="img-responsive" style="width:200px;height:200px;">
      </div>
      @endif
      <div class="form-group">
        <label>Ad Link</label>
        <input type="text" name="ad_link" required="required" class="form-control @error('ad_link') is-invalid @enderror" placeholder="Ad Link" value="{{$data->footer_custom_link ? $data->footer_custom_link : old('ad_link')}}">
        @error('ad_link')
          <span class="invalid-feedback" role="alert">
              <strong>{{ $message }}</strong>
          </span>
      @enderror
      </div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop