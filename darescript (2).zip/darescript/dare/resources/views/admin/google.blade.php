@extends('layouts.admin')

@section('content')

	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Google Analytics Code</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

		{!! Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1']]) !!}
			<div class="form-group">
				<label>Google Analytics Code</label>
				<textarea rows="6" class="form-control @error('google_analytics_code') is-invalid @enderror" required="required" name="google_analytics_code" placeholder="Code here...">{{$data->google_code ? $data->google_code : old('google_analytics_code')}}</textarea>
				@error('google_analytics_code')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
			</div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop