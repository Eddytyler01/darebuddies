@extends('layouts.admin')

@section('content')
<?php 
use App\User;
?>
<div id="content-wrapper">
<div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Icon Cards-->
        <div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  <i class="fas fa-fw fa-users"></i>
                </div>
                <div class="mr-5">{{number_format(count($user))}} Total Dare!</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="#">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  <i class="fas fa-angle-right"></i>
                </span>
              </a>
            </div>
          </div>

          
         
        
        </div>

       @if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-users"></i>
            Dare Performed</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                  	<th>S.No</th>
                   	<th>User Name</th>
                    <th>User Id</th>
                    <th>Question Type</th>
                    <th>No.of people played</th>
                    <th>Created At</th>
                    <th style="width:150px;">Operation</th>
                  </tr>
                </thead>
              
                <tbody>
                <?php $i = 1; ?>
                @foreach($user as $users)
                <?php $use = User::where('user_id', '=', $users->user_id)->where('status', '=', 1)->where('role_id', '=', 3)->count(); ?>
                	<tr>
                		<td>{{$i}}</td>
                		<td>{{$users->name}}</td>
                		<td>{{$users->user_id}}</td>
                    <td>@if($users->type == 1) Fill in the Blanks @elseif($users->type == 2) Objective Questions @else True/False @endif </td>
                		<td>{{number_format($use)}}</td>
                		<td>{{date('d M, Y', strtotime($users->created_at))}}</td>
                		<td>
                			{!! Form::open(['method'=>'DELETE', 'action'=>['AdminIndex@destroy', $users->id], 'onsubmit'=>'return confirm("Are You Sure?");']) !!}
                				<button class="btn btn-danger btn-sm"><i class="fa fa-trash fa-fw"></i></button>
                			{!! Form::close() !!}
                		</td>
                	</tr>

                <?php $i++; ?>
                @endforeach 

                </tbody>
              </table>
            </div>
          </div>
          
        </div>

      </div>
      <!-- /.container-fluid -->
@stop