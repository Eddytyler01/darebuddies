@extends('layouts.admin')

@section('content')
<div id="content-wrapper">
<div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Questions</li>
        </ol>

       <a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
       <a href=""  data-toggle="modal" data-target="#myModal" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add Question</a>
        <br/><br/>
        @if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif
        @if(Session::has('danger'))
            <div class="alert alert-danger">
                <strong> {{session('danger')}}</strong>
            </div><br/>
        @endif
       

        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-users"></i>
            Questions</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                  	<th>S.No</th>
                   	<th>Question</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th style="width:150px;">Operation</th>
                  </tr>
                </thead>
              
                <tbody>
                <?php $i = 1; ?>
                
                @foreach($question as $questions)

                  <tr>
                    <td>{{$i}}</td>
                    <td>{{$questions->question}}</td>
                    <td><a href="{{route('admin.show', $questions->id)}}" class="btn btn-sm btn-{{$questions->status ? 'success' : 'danger'}}">{{$questions->status ? 'Avtive' : 'Not-Avtice'}}</a></td>
                    <td>{{date('d M, Y', strtotime($questions->created_at))}}</td>
                    <td>
                      <a href="#" data-toggle="modal" data-target="#edit{{$i}}" class="btn btn-success btn-sm float-left"><i class="fa fa-edit"></i></a>
                      {!! Form::open(['method'=>'DELETE', 'action'=>['AdminIndex@destroy', $questions->id]]) !!}
                        <button class="btn btn-danger btn-sm float-left" style="margin-left:10px;"><i class="fa fa-trash fa-fw"></i></button>
                      {!! Form::close() !!}
                    </td>
                  </tr>
<div class="modal" id="edit{{$i}}">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Edit Question</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        {!! Form::model($question, ['method'=>'PATCH', 'action'=>['AdminIndex@update', $questions->id]]) !!}
        <div class="form-group">
          <label>Edit Question</label>
          <input type="text" name="question" placeholder="Edit Question" value="{{$questions->question}}" required="required" class="form-control">
        </div>
        <div class="form-group">
          <center><button class="btn btn-success btn-sm">Update</button></center>
        </div>
        {!! Form::close() !!}        
      </div>


    </div>
  </div>
</div>
                <?php $i++; ?>
                @endforeach

                </tbody>
              </table>
            </div>
          </div>
          
        </div>

      </div>
      <!-- /.container-fluid -->
      <!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Question</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        {!! Form::open(['method'=>'POST', 'action'=>'AdminIndex@store']) !!}
        <div class="form-group">
          <label>Add Question</label>
          <input type="text" name="question" placeholder="Add Question" required="required" class="form-control">
        </div>
        <div class="form-group">
          <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>
        {!! Form::close() !!}        
      </div>


    </div>
  </div>
</div>
@stop