@extends('layouts.admin')

@section('content')
<style type="text/css">
  #mceu_44
  {
    display:none!important;
  }
</style>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>tinymce.init({ selector:'#footer',
    plugins: [
        "advlist autolink lists charmap print preview hr pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime nonbreaking save contextmenu directionality",
        "paste textcolor colorpicker"
    ],
    toolbar1: "undo redo | styleselect fontselect | fontsizeselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
    toolbar2: "link | colorpicker forecolor backcolor | preview ",

 });

</script>
	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{route('admin.index')}}">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Site Settings</li>
        </ol>

		<a href="{{route('admin.index')}}" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		@if(Session::has('insert'))
            <div class="alert alert-success">
                <strong> {{session('insert')}}</strong>
            </div><br/>
        @endif

		{!! Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1'], 'files'=>true]) !!}
			<div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="site_name" required="required" class="form-control @error('site_name') is-invalid @enderror" placeholder="Site Name" value="{{$data->site_name ? $data->site_name : old('site_name')}}">
            @error('site_name')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label>Site Title</label>
            <input type="text" name="site_title" required="required" class="form-control @error('site_title') is-invalid @enderror" placeholder="Site Title" value="{{$data->site_title ? $data->site_title : old('site_title')}}">
            @error('site_title')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
          </div>
        </div>
      </div>
      <div class="form-group">
        <label>Meta Description</label>
        <textarea rows="4" name="site_description" required="required" class="form-control @error('site_description') is-invalid @enderror" placeholder="Meta Description">{{$data->site_description ? $data->site_description : old('site_description')}}</textarea>
        @error('site_description')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
      </div>
      <div class="form-group">
        <label>Meta Keywords</label>
        <input type="text" name="site_keywords" required="required" placeholder="site_keywords" class="form-control @error('site_keywords') is-invalid @enderror" value="{{$data->site_keywords ? $data->site_keywords : old('site_keywords')}}">
        @error('site_keywords')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
      </div>
      <div class="form-group">
        <label>Site Verification Code</label>
        <input type="text" name="verification" placeholder="verification" class="form-control @error('verification') is-invalid @enderror" value="{{$data->verification ? $data->verification : old('verification')}}">
        @error('verification')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
      </div>
      <div class="form-group">
        <label>Open Graph Image</label>
        <input type="file" name="og_image" class="form-control @error('og_image') is-invalid @enderror">
        @error('og_image')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
      </div>
      @if($data->og_image != null)
      <div class="form-group">
        <label>OG Image</label><br/>
        <img src="{{url('/')}}/images/{{$data->og_image}}" class="img-responsive" style="width:120px;height:120px;">
      </div>
      @endif
      <div class="form-group">
        <label>Footer Data</label>
        <textarea class="form-control @error('footer') is-invalid @enderror" name="footer" style="min-height:300px;" id="footer">{{$data->footer ? $data->footer : old('footer')}}</textarea>
        @error('footer')
          <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
          </span>
        @enderror
      </div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		{!! Form::close() !!}

@stop