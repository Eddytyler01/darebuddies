<!DOCTYPE html>
<html>
<head>
    <title>Login | {{$data->site_name ? $data->site_name : 'JJ Dare'}}</title>
@extends('layouts.main')

@section('content')

<div class="container padding">
    <div class="row">
        <div class="col-md-12">
            <div class="login-form">
                <form method="POST" action="{{ route('login') }}">
                        @csrf
                    <h2 class="text-center">Log In</h2>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="Username" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" required="required">
                        @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" placeholder="Password" class="form-control @error('password') is-invalid @enderror" required="required">
                        @error('password')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary">Log In</button>
                    </div>
                    <div class="clearfix">
                        <label class="pull-left checkbox-inline">
                            <input type="checkbox">Remember me
                        </label>
                        <!-- <a href="#" class="pull-right">Forgot Password</a> -->
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@stop