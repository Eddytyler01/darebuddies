<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}} | Contact Us</title>

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>Contact Us</h1>
        <div class="main_box">
        	@if($data->contant_us == null)
        	<center><strong>No Record Found!</strong></center>
        	@else
            <?php echo $data->contant_us; ?>
        	@endif
        </div>
    </div>
</div>
@stop