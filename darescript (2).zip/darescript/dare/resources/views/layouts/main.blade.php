	
	<link rel="stylesheet" href="{{url('/')}}/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="{{url('/')}}/css/style.css">
	<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<?php echo $data->verification ? $data->verification : ''; ?>
</head>
<body>

	<div class="container top-header">
	    <nav class="navbar navbar-default">
	        <div class="container">
	            <div class="navbar-header">
	                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                </button>
	                <a class="navbar-brand" href="{{url('/')}}"><i class="fa fa-ravelry fa-fw"></i> {{$data->site_name ? $data->site_name : 'JJ Dare'}}</a>
	            </div>
	            <div class="collapse navbar-collapse" id="myNavbar">
	                <ul class="nav navbar-nav">
	                    <li><a href="{{url('/')}}">Home</a></li>
	                    <li><a href="{{url('/about-us')}}">About Us</a></li>
	                    <li><a href="{{url('/contact-us')}}">Contact Us</a></li>
	                    <!-- <li><a href="{{url('/login')}}">Login</a></li> -->
	                </ul>
	            </div>
	        </div>
	    </nav> 
	</div>

	<center><span class="ad_class"><?php echo $data->header_ad ? $data->header_ad : ''; ?></span></center>

	@yield('content')

	@if($data->footer_custom_ad != null && $data->footer_custom_link != null)

	<div class="footer_istehar">
		<center><a href="{{$data->footer_custom_link}}" target="_blank"><img src="{{url('/')}}/images/{{$data->footer_custom_ad}}" class="img-responsive" alt="{{$data->site_name ? $data->site_name : 'JJ Dare'}}"></a></center>
	</div>

	@endif

	<center><span class="ad_class"><?php echo $data->footer_ad ? $data->footer_ad : ''; ?></span></center>

	@if($data->footer != null)
	
	<div class="container first_half">
    	<div class="">
        	<div class="main_box">
        		<?php echo $data->footer ? $data->footer : ''; ?>
        	</div>
    	</div>
	</div>

	@endif

	<div class="container top-header">
		<div class="footer">
			<p><strong>Disclaimer:</strong> All content is provided for fun and entertainment purpose only </p>
			<p class="text-center">© {{Date('Y')}} {{$data->site_name ? $data->site_name : 'JJ Dare'}} All rights Reserved</p>
			<div class="text-center">
				<a href="{{url('/privacy-policy')}}">Privacy Policy</a> | <a href="{{url('/terms-&-conditions')}}">Terms & Conditions</a>
			</div>
		</div>
	</div>

	@yield('footer')
	<?php echo $data->google_code ? $data->google_code : ''; ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>