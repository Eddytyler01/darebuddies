<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <style type="text/css">
        .result_link
        {
            text-align:left!important;
        }
    </style>
@extends('layouts.main')

@section('content')
<?php 
use Illuminate\Support\Facades\Crypt;
?>

@if(isset($make))
<div class="container first_half">
    
    @if(Session::has('insert'))
        <div class="alert alert-success text-center">
            <strong> {{session('insert')}}</strong>
        </div>
    @endif
    <div class="">
        <h1>Create Questions </h1>
        <div class="main_box">
            <h2 class="text-primary"> @if($make == 2) Objective Questions @else  True / False Questions @endif </h2><br/>
            <div class="row">
                <div class="col-md-12">
                    @if(count($question) >= 10)
                    <strong class="text-center text-danger">Can't add more than 10 questions!!</strong>
                    @else
                    {!! Form::open(['method'=>'POST', 'url'=>'/create-record']) !!}
                        <div class="form-group">
                            <label>Enter Question</label>
                            <input type="text" name="question" class="form-control @error('question') is-invalid @enderror" placeholder="Enter your question" required="required" value="{{old('question')}}">
                            @error('question')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        @if($make == 2)
                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label>Option A</label>
                                    <input type="text" name="a1" class="form-control @error('a1') is-invalid @enderror" placeholder="Option A" required="required" value="{{old('a1')}}">
                                    @error('a1')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label>Option B</label>
                                    <input type="text" name="a2" class="form-control @error('a2') is-invalid @enderror" placeholder="Option B" required="required" value="{{old('a2')}}">
                                    @error('a2')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <div class="form-group">
                                    <label>Option C</label>
                                    <input type="text" name="a3" class="form-control @error('a3') is-invalid @enderror" placeholder="Option C" required="required" value="{{old('a3')}}">
                                    @error('a3')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <div class="form-group">
                                    <label>Option D</label>
                                    <input type="text" name="a4" class="form-control @error('a4') is-invalid @enderror" placeholder="Option D" required="required" value="{{old('a4')}}">
                                    @error('a4')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Correct Answer</label>
                                    <select class="form-control" required="required" name="correct">
                                        <option value="">Select Correct Answer</option>
                                        <option value="A">Option A</option>
                                        <option value="B">Option B</option>
                                        <option value="C">Option C</option>
                                        <option value="D">Option D</option>
                                    </select>
                                    @error('a4')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        
                        
                        @else
                        <div class="form-group">
                            <label>Select Correct Answer</label>
                            <select class="form-control" name="correct" required="required">
                                <option value="">Select Correct Answer</option>
                                <option value="True">True</option>
                                <option value="False">False</option>
                            </select>
                            <input type="hidden" name="trfa" value="0">
                        </div>
                        @endif
                        <div class="form-group">
                            <center><button class="btn btn-success">Submit</button></center>
                        </div>
                    {!! Form::close() !!}
                    @endif
                </div>
            </div>
        </div>
        @if(count($question) != 0)
        <div class="main_box">
            <h2 class="text-primary"> Your Questions <small class="text-danger"><strong>Complete 10 questions to proceed!</strong></small></h2>
            <?php $i = 1; ?>
            @foreach($question as $ques)
            <div class="result_link">
                <strong>{{$i}}</strong>. {{$ques->question}}<br/>
                <small class="text-success"><strong>Ans</strong>. {{$ques->correct}}</small>
                <a href="{{url('/delete-question', Crypt::encrypt($ques->id))}}" onclick="return confirm('Are you sure?');" class="btn btn-danger btn-sm pull-right" style="margin-top:-15px;"><i class="fa fa-trash"></i></a>
            </div>
            <?php $i++; ?>
            @endforeach
            @if(count($question) >= 10)
            <br/>
            {!! Form::open(['method'=>'POST', 'url'=>'/create-record']) !!}
                <input type="hidden" name="user_id" value="0">
                <center>
                    <button class="btn btn-primary">Proceed</button>
                </center>
            {!! Form::close() !!}
            @endif
        </div>
        @endif
        
    </div>
</div>
@else
<div class="container first_half">
    @if(Session::has('danger'))
        <div class="alert alert-danger text-center">
            <strong> {{session('danger')}}</strong>
        </div>
    @endif
    <div class="">
        <h1>Make your own Questions </h1>
        <div class="main_box">
            <h2 class="text-primary">Question Type:</h2><br/>
            <div class="row">
                <div class="col-xs-6">
                    <center>
                        <a href="{{url('/create-question', Crypt::encrypt(2))}}">
                            <img src="{{url('/')}}/images/list.png" class="img-responsive" alt="Optional">
                            <h3>Objective</h3>
                        </a>
                    </center>
                </div>
                <div class="col-xs-6">
                    <center>
                        <a href="{{url('/create-question', Crypt::encrypt(3))}}">
                            <img src="{{url('/')}}/images/trfa.png" style="width:135px;" class="img-responsive" alt="True/False">
                            <h3>True/False</h3>
                        </a>
                    </center>
                </div>
            </div>
        </div>
        
    </div>
</div>
@endif
@stop