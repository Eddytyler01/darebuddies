<!DOCTYPE html>
<html>
<head>
    <title>I want your answer let see how much you know about me? | {{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <meta name="description"  content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta name="keywords"  content="{{$data->site_keywords ? $data->site_keywords : 'Enter keywords'}}" />
    <link rel="canonical" href="{{url('/')}}/match/{{$user->user_id}}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="I want your answer let ses how much you know about me? | {{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:description" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta property="og:url" content="{{url('/')}}/match/{{$user->user_id}}" />
    <meta property="og:site_name" content="I want your answer let ses how much you know about me? | {{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta name="twitter:text:title" content="I want your answer let ses how much you know about me? | {{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta name="twitter:card" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>Get ready to fill {{$user->name}}'s Diary </h1>
        
        <div class="main_box">
            {!! Form::open(['method'=>'POST', 'url'=>'/create-record']) !!}
            <input type="hidden" name="id" value="{{$id}}">
                <div class="form-group">
                    <input type="text" name="player" class="form-control" required="required" placeholder="Enter your name ( Ex: Esha )">
                </div>
                <center><button class="btn btn-primary btn-sm"><i class="fa fa-paper-plane fa-fw"></i> Start</button></center>
            {!! Form::close() !!}
        </div>
        <div class="main_box">
            <h2 class="text-primary">Instructions:</h2>
            <ul>
                <li>Enter your name.</li>
                <li>Write not more than 10 honest answers about your friend. </li>
                <li>View your answers at the Dareboard. </li>
            </ul>
        </div>
    </div>
</div>
@stop