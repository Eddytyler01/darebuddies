<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | {{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <style type="text/css">
        .result_link
        {
            text-align:left!important;
        }
    </style>

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="" id="select">
        <h1>Choose your option! </h1>
        <div class="main_box">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="text-primary text-center">Already Made Questions</h2>
                    <a href="javascript:void(0)" onclick="gogreen()" style="width:100%;" class="btn btn-primary">Get Started!</a><br/><br/>
                </div>
                <div class="col-md-6">
                    <h2 class="text-primary text-center">Make Your Own Questions</h2>
                    <a href="{{url('/make-question')}}" style="width:100%;" class="btn btn-primary">Get Started!</a><br/><br/>
                </div>
            </div>          
        </div>

        
       
    </div>
    <div class="" id="questions">
        <h1>Your Diary will have these questions! </h1>
        <div class="main_box">
            @if(count($question) == 0)
                <div class="result_link text-danger">
                    <center><strong>This diary is not ready! please check after sometime!!</strong></center>
                </div> 
                <br/>
                <center><a href="javascript:void(0)" class="btn btn-success" onclick="goback()"><i class="fa fa-arrow-left"></i> Go Back</a></center>
            @else
                <?php $i = 1; ?>
                @foreach($question as $questions)
                <div class="result_link">
                    {{$questions->question}}
                </div>
                <?php $i++; ?>
                @endforeach

                <br/>
                {!! Form::open(['method'=>'POST', 'url'=>'/create-record']) !!}
                <input type="hidden" name="user_id" value="{{$user->user_id}}">
                <center>
                    <a href="javascript:void(0)" class="btn btn-success" onclick="goback()"><i class="fa fa-arrow-left"></i> Go Back</a>
                    <button class="btn btn-primary">Proceed</button>
                </center>
                {!! Form::close() !!}
            @endif
        </div>

        
       
    </div>
</div>
@stop
@section('footer')
<script type="text/javascript">
    function gogreen() 
    {
        $('#select').hide();
        $('#questions').show();
    }
    function goback() 
    {
        $('#questions').hide();
        $('#select').show();
    }
</script>
@stop
