<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}} | Privacy Policy</title>

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>Privacy Policy </h1>
        <div class="main_box">
        	@if($data->policy == null)
        	<center><strong>No Record Found!</strong></center>
        	@else
            <?php echo $data->policy; ?>
            @endif
        </div>
    </div>
</div>
@stop