<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <style type="text/css">
        .result_link
        {
            text-align:left!important;
        }
    </style>
    @if($user->type == 3)
    
        <style type="text/css">
        

        [type=radio] 
        { 
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
        }

        [type=radio] + img 
        {
          cursor: pointer;
        }

        </style>
    @endif
    
@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>{{$user->name}}'s Diary  </h1>
        <div class="main_box">
            <h2 class="text-primary">Questions:</h2>
            @if($question)
            <div class="result_link">
                {{$quesno}}. {{$question->question}}
            </div> 
            {!! Form::open(['method'=>'POST', 'url'=>'/create-record', 'id'=>'frommy']) !!}
            <input type="hidden" name="quesno" value="{{$quesno}}">
            <input type="hidden" name="quesid" value="{{$question->id}}">
            @if($user->type == 1)
            <div class="result_link">
                <textarea rows="4" class="form-control" placeholder="Type your answer here..." required="required" name="answer">{{$ans_given ? $ans_given->ans_given : old('answer')}}</textarea>
            </div><br/>
            <center><button class="btn btn-success">Continue</button></center>
            @elseif($user->type == 2)
            <br/>
            <div class="result_link">
                <input type="radio" name="answer" required="required" {{ ($ans_given['ans_given'] == 'A') ? 'checked' : '' }} onclick="this.form.submit()" value="A"> {{$question->a1}}
            </div>
            <div class="result_link">
                <input type="radio" name="answer" required="required" {{ ($ans_given['ans_given'] == 'B') ? 'checked' : '' }} onclick="this.form.submit()" value="B"> {{$question->a2}}
            </div>
            <div class="result_link">
                <input type="radio" name="answer" required="required" {{ ($ans_given['ans_given'] == 'C') ? 'checked' : '' }} onclick="this.form.submit()" value="C"> {{$question->a3}}
            </div>
            <div class="result_link">
                <input type="radio" name="answer" required="required" {{ ($ans_given['ans_given'] == 'D') ? 'checked' : '' }} onclick="this.form.submit()" value="D"> {{$question->a4}}
            </div>
            @else
            <br/>
            <div class="row">
                <div class="col-xs-6">
                    <center>
                        <input type="radio" id="ans1" name="answer" value="True">
                        <img src="{{url('/')}}/images/true.png" id="yesimg"  class="img-responsive" alt="Optional">
                        <h3><b>True</b></h3>
                    </center>
                </div>
                <div class="col-xs-6">
                    <center>
                        <input type="radio" id="ans2" name="answer" value="False">
                        <img src="{{url('/')}}/images/false.png" id="noimg" style="width:122px;" class="img-responsive" alt="True/False">
                        <h3><b>False</b></h3>
                    </center>
                </div>
            </div>
            @endif
            
            {!! Form::close() !!}
            @endif
        </div>
        
    </div>
</div>
@stop
@section('footer')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
  window.history.forward(1);

    $('#yesimg').click(function()
    {
        $('#ans1').attr('checked','checked');
        $('#ans2').removeAttr('checked');
        $('#frommy').submit();
    });

    $('#noimg').click(function()
    {
        $('#ans2').attr('checked','checked');
        $('#ans1').removeAttr('checked');
        $('#frommy').submit();
    });

    
</script>
@stop