<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | {{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description"  content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta name="keywords"  content="{{$data->site_keywords ? $data->site_keywords : 'Enter keywords'}}" />
    <link rel="canonical" href="{{url('/')}}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:description" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta property="og:url" content="{{url('/')}}" />
    <meta property="og:site_name" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta name="twitter:text:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta name="twitter:card" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <style type="text/css">
      .result_link
      {
        text-align:left!important;
      }
      #copy_text
      {
        overflow:hidden;
      }
    </style>
@extends('layouts.main')

@section('content')
<?php 
use App\Answer;
?>
<div class="container first_half">
    <div class="">
        <h1>{{$user->name}} Your Diary is Ready! </h1>
        <div class="main_box">
            <h2 class="text-primary text-center"> 
                Now share the link with your friends!
                <br/>
                Let them answer all your questions 
            </h2>
            <div class="result_link" id="copy_text" style="text-align:center!important;">
                {{url('/')}}/match/{{$user->user_id}}
            </div><br/>
            <a href="javascript:void(0)" onclick="copy_text()" class="btn btn-primary" style="width:100%;"><i class="fa fa-copy fa-fw"></i> Copy Link</a>
        </div>
        <br/>
        <a href="whatsapp://send?text=*10 Questions About {{$user->name}}*%0A%0A*I Want Your Answers*🤗🙏%0A%0AThis will help me to know what you think about me%0A%0AClick Now👇%0A%0A{{url('/')}}/match/{{$user->user_id}}" class="border whatsapp">
            <i class="fa fa-whatsapp fa-fw"></i> Whatsapp Status
        </a>
        <div class="row">
            <div class="col-xs-6" style="padding-right:6px;">
                <a href="https://www.facebook.com/sharer/sharer.php?kid_directed_site=0&u={{url('/')}}/match/{{$user->user_id}}%2F&display=popup&ref=plugin&src=share_button" class="border facebook">
                    <i class="fa fa-facebook fa-fw"></i> Facebook
                </a>
            </div>
            <div class="col-xs-6" style="padding-left:6px;">
                <a href="https://twitter.com/intent/tweet?text=Title&url={{url('/')}}/match/{{$user->user_id}}%2F" class="border twitter">
                    <i class="fa fa-twitter fa-fw"></i> Twitter
                </a>
            </div>
        </div>
        <h1>Dareboard of {{$user->name}}  </h1>
        <div class="main_box">
           <div class="table-responsive">
            @if(count($dare) == 0)
            <center>No Record Found!</center>
            @else
            @if($user->type == 1)
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                        <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Answers</th>
                           <th style="width:200px;">Operation</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                    @foreach($dare as $dares)
                       <tr>
                          <td>{{$i}}</td>
                           <td>{{$dares->name}}</td>
                           <td><a href="" data-toggle="modal" data-target="#myModal{{$i}}" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a></td>
                           <td>
                               {!! Form::open(['method'=>'GET', 'url'=>['delete', $dares->id], 'onsubmit'=>'return confirm("Are You Sure?");']) !!}
                                <button class="btn btn-danger btn-sm"><i class="fa fa-trash fa-fw"></i></button>
                               {!! Form::close() !!}
                           </td>
                       </tr>
                       <div class="modal" id="myModal{{$i}}">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">{{$dares->name}}'s answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          <?php $ie = 1; $ans = Answer::where('user_id', '=', $dares->id)->orderBy('id', 'ASC')->get(); ?>
          @foreach($ans as $ansa)
          <div class="result_link">
              <strong>{{$ie}}</strong>. {{$ansa->question->question}}<br/>
              <small><strong class="text-success">Ans</strong>. {{$ansa->ans_given}}</small>
          </div>
          <?php $ie++; ?>
          @endforeach
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                       <?php $i++; ?>
                       @endforeach
                   </tbody>
               </table>
               @else
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th style="width:80px;">S.No</th>
                      <th>Name</th>
                      <th style="width:200px;">Score</th>
                      <th style="width:200px;">Answers</th>
                      <th style="width:200px;">Operation</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                      <?php $i = 1; ?>
                    @foreach($dare as $dares)
                      <tr>
                        <td>{{$i}}</td>
                        <td>{{$dares->name}}</td>
                        <td>{{$dares->result}} / 10</td>
                        <td><a href="" data-toggle="modal" data-target="#myModal{{$i}}" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a></td>
                        <td>{!! Form::open(['method'=>'GET', 'url'=>['delete', $dares->id], 'onsubmit'=>'return confirm("Are You Sure?");']) !!}
                                <button class="btn btn-danger btn-sm"><i class="fa fa-trash fa-fw"></i></button>
                               {!! Form::close() !!}</td>
                      </tr>
                      <div class="modal" id="myModal{{$i}}">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">{{$dares->name}}'s answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          <?php $ie = 1; $ans = Answer::where('user_id', '=', $dares->id)->orderBy('id', 'ASC')->get(); ?>
          @foreach($ans as $ansa)
          <div class="result_link">
              <strong>{{$ie}}</strong>. {{$ansa->question->question}}<br/>
              <small><strong class="text-success">Correct Ans</strong>. {{$ansa->question->correct}}</small> | <small><strong class="text-success">You Given</strong>. {{$ansa->ans_given}}</small>
          </div>
          <?php $ie++; ?>
          @endforeach
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    <?php $i++; ?>
                    @endforeach
                    
                  </tbody>
                </table>
               @endif
               @endif
           </div>
        </div>
    </div>
</div>
@stop
@section('footer')
<script type="text/javascript">
    function copy_text() 
    {
        let shareLink = document.getElementById("copy_text");
        var range = document.createRange();
        range.selectNodeContents(shareLink);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('copy');
        alert('Copied!!');
    }
</script>
@stop