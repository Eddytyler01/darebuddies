<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}} | Terms & Conditions</title>

@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>Terms & Conditions </h1>
        <div class="main_box">
        	@if($data->tc == null)
        	<center><strong>No Record Found!</strong></center>
        	@else
            <?php echo $data->tc; ?>
            @endif
        </div>
    </div>
</div>
@stop