<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | {{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <meta name="description"  content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta name="keywords"  content="{{$data->site_keywords ? $data->site_keywords : 'Enter keywords'}}" />
    <link rel="canonical" href="{{url('/')}}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:description" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta property="og:url" content="{{url('/')}}" />
    <meta property="og:site_name" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta name="twitter:text:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta name="twitter:card" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <style type="text/css">
      .result_link
      {
        text-align:left!important;
      }
    </style>
@extends('layouts.main')

@section('content')
<div class="container first_half">
    <div class="">
        <h1>Now, it’s your turn.<br/>
        Create your own Diary and send it to your friends!  </h1>
        <center><a href="{{url('/create-new')}}" class="btn btn-primary">Create Your Own Diary</a></center>
        <h1>Your answers about {{$user->name}} are ready. Check Now!!</h1>
        <div class="main_box">
           <div class="table-responsive">
            @if($user->type == 1)
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                          <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Answers</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                      @foreach($dare as $dares)
                       <tr>
                        <td>{{$i}}</td>
                           <td>{{$dares->name}}</td>
                           <td>
                            @if($dares->id == $_COOKIE['jjdareuser'])
                            <a href="#"  data-toggle="modal" data-target="#myModal" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a>
                            @else
                            <a href="#" class="btn btn-danger btn-sm">----</a>
                            @endif
                          </td>
                       </tr>
                      
                      <?php $i++; ?>
                       @endforeach
                   </tbody>
               </table>
               @else
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                          <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Score</th>
                           <th style="width:200px;">Answers</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                      @foreach($dare as $dares)
                       <tr>
                        <td>{{$i}}</td>
                           <td>{{$dares->name}}</td>
                           <td>{{$dares->result}} / 10</td>
                           <td>
                            @if($dares->id == $_COOKIE['jjdareuser'])
                            <a href="#"  data-toggle="modal" data-target="#myModal" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a>
                            @else
                            <a href="#" class="btn btn-danger btn-sm">----</a>
                            @endif
                          </td>
                       </tr>
                      
                      <?php $i++; ?>
                       @endforeach
                   </tbody>
               </table>
               @endif
           </div>
        </div>
        
       
        
        
    </div>
</div>
 <div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          @if($user->type == 1)
          <?php $i = 1; ?>
          @foreach($ans as $ansa)
          <div class="result_link">
              <strong>{{$i}}</strong>. {{$ansa->question->question}}<br/>
              <small><strong class="text-success">Ans</strong>. {{$ansa->ans_given}}</small>
          </div>
          <?php $i++; ?>
          @endforeach
          @else
          <?php $i = 1; ?>
          @foreach($ans as $ansa)
          <div class="result_link">
              <strong>{{$i}}</strong>. {{$ansa->question->question}}<br/>
              <small><strong class="text-success">Correct Ans</strong>. {{$ansa->question->correct}}</small> | <small><strong class="text-success">You Given</strong>. {{$ansa->ans_given}}</small>
          </div>
          <?php $i++; ?>
          @endforeach
          @endif
          
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
@stop

