<!DOCTYPE html>
<html>
<head>
    <title>{{$data->site_title ? $data->site_title : 'JJ Dare'}}</title>
    <meta name="description"  content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta name="keywords"  content="{{$data->site_keywords ? $data->site_keywords : 'Enter keywords'}}" />
    <link rel="canonical" href="{{url('/')}}" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:description" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
    <meta property="og:url" content="{{url('/')}}" />
    <meta property="og:site_name" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta property="og:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="{{url('/')}}/images/{{$data->og_image ? $data->og_image : ''}}" />
    <meta name="twitter:text:title" content="{{$data->site_title ? $data->site_title : 'JJ Dare'}}" />
    <meta name="twitter:card" content="{{$data->site_description ? $data->site_description : 'Enter Description'}}" />
@extends('layouts.main')

@section('content')

<div class="container first_half">
    <div class="">
        <h1>Create your own Diary!!</h1>
        <div class="main_box">
            <h2 class="text-primary">Instructions:</h2>
            <ul>
                <li>Enter your name.</li>
                <li>Create your diary.</li>
                <li>Share the link with your friends. </li>
                <li>They will answer all your questions.</li>
                <li>Check their answers on Dareboard. </li>
            </ul>
        </div>
        <div class="main_box">
            {!! Form::open(['method'=>'POST', 'url'=>'/create-record']) !!}
                <div class="form-group">
                    <input type="text" name="name" class="form-control" required="required" placeholder="Enter your name ( Ex: Esha )">
                </div>
                <center><button class="btn btn-primary btn-sm"><i class="fa fa-paper-plane fa-fw"></i> Submit</button></center>
            {!! Form::close() !!}
        </div>
    </div>
</div>
@stop