<?php

use Illuminate\Support\Facades\Route;
use App\Data;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::resource('/', 'MainIndex');

Route::get('/create-new', 'MainIndex@new');

Route::post('/create-record', 'MainIndex@store');

Route::get('/option/{id}', 'MainIndex@create');

Route::get('/result/{id}', 'MainIndex@show');

Route::get('/match/{id}', 'MainIndex@match');

Route::get('/quiz/{id}', 'MainIndex@quiz');

Route::get('/dare-board', 'MainIndex@dareboard');

Route::get('/delete/{id}', 'MainIndex@destroy');

Route::get('/make-question', 'MainIndex@makeq');

Route::get('/delete-question/{id}', 'MainIndex@edit');

Route::get('/create-question/{id}', 'MainIndex@type');

Route::get('about-us', 'MainIndex@about');

Route::get('contact-us', 'MainIndex@contact');

Route::get('/privacy-policy', 'MainIndex@privacy');

Route::get('/terms-&-conditions', 'MainIndex@terms');

Route::group(['middleware'=>'admin'], function(){

	Route::resource('admin', 'AdminIndex');

	Route::get('google-analytics-code', 'AdminIndex@google');

	Route::get('ads-settings', 'AdminIndex@ads');

	Route::get('site-settings', 'AdminIndex@site');

	Route::get('question', 'AdminIndex@question');

	Route::get('about', 'AdminIndex@about');

	Route::get('contact', 'AdminIndex@contact');

	Route::get('/p-policy', 'AdminIndex@privacy');

	Route::get('/t-&-conditions', 'AdminIndex@terms');

	Route::get('/custom-footer-ad', 'AdminIndex@custom');

	Route::get('/change-password', 'AdminIndex@changepass');

	Route::post('/changep', 'AdminIndex@changep');

});


Route::get('/jj-login', function () {
	
	$data = Data::first();

	return view('auth.login1', compact('data'));
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
