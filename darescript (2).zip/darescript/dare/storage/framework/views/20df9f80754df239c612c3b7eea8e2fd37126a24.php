<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?> | Privacy Policy</title>



<?php $__env->startSection('content'); ?>

<div class="container first_half">
    <div class="">
        <h1>Privacy Policy </h1>
        <div class="main_box">
            <?php echo $data->policy; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/policy.blade.php ENDPATH**/ ?>