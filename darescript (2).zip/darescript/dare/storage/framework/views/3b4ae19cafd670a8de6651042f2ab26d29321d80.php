<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?></title>
    <meta name="description"  content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta name="keywords"  content="<?php echo e($data->site_keywords ? $data->site_keywords : 'Enter keywords'); ?>" />
    <link rel="canonical" href="<?php echo e(url('/')); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:description" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta property="og:url" content="<?php echo e(url('/')); ?>" />
    <meta property="og:site_name" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta name="twitter:text:title" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta name="twitter:card" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <style type="text/css">
      .result_link
      {
        text-align:left!important;
      }
    </style>


<?php $__env->startSection('content'); ?>
<div class="container first_half">
    <div class="">
        <h1>Now, it’s your turn.<br/>
        Create your own Diary and send it to your friends!  </h1>
        <center><a href="<?php echo e(url('/create-new')); ?>" class="btn btn-primary">Create Your Own Diary</a></center>
        <h1>Your answers about <?php echo e($user->name); ?> are ready. Check Now!!</h1>
        <div class="main_box">
           <div class="table-responsive">
            <?php if($user->type == 1): ?>
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                          <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Answers</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                      <?php $__currentLoopData = $dare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dares): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                        <td><?php echo e($i); ?></td>
                           <td><?php echo e($dares->name); ?></td>
                           <td>
                            <?php if($dares->id == $_COOKIE['jjdareuser']): ?>
                            <a href="#"  data-toggle="modal" data-target="#myModal" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a>
                            <?php else: ?>
                            <a href="#" class="btn btn-danger btn-sm">----</a>
                            <?php endif; ?>
                          </td>
                       </tr>
                      
                      <?php $i++; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
               </table>
               <?php else: ?>
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                          <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Score</th>
                           <th style="width:200px;">Answers</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                      <?php $__currentLoopData = $dare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dares): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                        <td><?php echo e($i); ?></td>
                           <td><?php echo e($dares->name); ?></td>
                           <td><?php echo e($dares->result); ?> / 10</td>
                           <td>
                            <?php if($dares->id == $_COOKIE['jjdareuser']): ?>
                            <a href="#"  data-toggle="modal" data-target="#myModal" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a>
                            <?php else: ?>
                            <a href="#" class="btn btn-danger btn-sm">----</a>
                            <?php endif; ?>
                          </td>
                       </tr>
                      
                      <?php $i++; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
               </table>
               <?php endif; ?>
           </div>
        </div>
        
       
        
        
    </div>
</div>
 <div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          <?php if($user->type == 1): ?>
          <?php $i = 1; ?>
          <?php $__currentLoopData = $ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ansa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="result_link">
              <strong><?php echo e($i); ?></strong>. <?php echo e($ansa->question->question); ?><br/>
              <small><strong class="text-success">Ans</strong>. <?php echo e($ansa->ans_given); ?></small>
          </div>
          <?php $i++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <?php $i = 1; ?>
          <?php $__currentLoopData = $ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ansa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="result_link">
              <strong><?php echo e($i); ?></strong>. <?php echo e($ansa->question->question); ?><br/>
              <small><strong class="text-success">Correct Ans</strong>. <?php echo e($ansa->question->correct); ?></small> | <small><strong class="text-success">You Given</strong>. <?php echo e($ansa->ans_given); ?></small>
          </div>
          <?php $i++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/userresult.blade.php ENDPATH**/ ?>