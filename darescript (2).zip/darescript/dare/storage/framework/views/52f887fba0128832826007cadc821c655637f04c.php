

<?php $__env->startSection('content'); ?>
<div id="content-wrapper">
<div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Questions</li>
        </ol>

       <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
       <a href=""  data-toggle="modal" data-target="#myModal" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Add Question</a>
        <br/><br/>
        <?php if(Session::has('insert')): ?>
            <div class="alert alert-success">
                <strong> <?php echo e(session('insert')); ?></strong>
            </div><br/>
        <?php endif; ?>
        <?php if(Session::has('danger')): ?>
            <div class="alert alert-danger">
                <strong> <?php echo e(session('danger')); ?></strong>
            </div><br/>
        <?php endif; ?>
       

        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-users"></i>
            Questions</div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                  	<th>S.No</th>
                   	<th>Question</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th style="width:150px;">Operation</th>
                  </tr>
                </thead>
              
                <tbody>
                <?php $i = 1; ?>
                
                <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($questions->question); ?></td>
                    <td><a href="<?php echo e(route('admin.show', $questions->id)); ?>" class="btn btn-sm btn-<?php echo e($questions->status ? 'success' : 'danger'); ?>"><?php echo e($questions->status ? 'Avtive' : 'Not-Avtice'); ?></a></td>
                    <td><?php echo e(date('d M, Y', strtotime($questions->created_at))); ?></td>
                    <td>
                      <a href="#" data-toggle="modal" data-target="#edit<?php echo e($i); ?>" class="btn btn-success btn-sm float-left"><i class="fa fa-edit"></i></a>
                      <?php echo Form::open(['method'=>'DELETE', 'action'=>['AdminIndex@destroy', $questions->id]]); ?>

                        <button class="btn btn-danger btn-sm float-left" style="margin-left:10px;"><i class="fa fa-trash fa-fw"></i></button>
                      <?php echo Form::close(); ?>

                    </td>
                  </tr>
<div class="modal" id="edit<?php echo e($i); ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Edit Question</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <?php echo Form::model($question, ['method'=>'PATCH', 'action'=>['AdminIndex@update', $questions->id]]); ?>

        <div class="form-group">
          <label>Edit Question</label>
          <input type="text" name="question" placeholder="Edit Question" value="<?php echo e($questions->question); ?>" required="required" class="form-control">
        </div>
        <div class="form-group">
          <center><button class="btn btn-success btn-sm">Update</button></center>
        </div>
        <?php echo Form::close(); ?>        
      </div>


    </div>
  </div>
</div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
          </div>
          
        </div>

      </div>
      <!-- /.container-fluid -->
      <!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Question</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <?php echo Form::open(['method'=>'POST', 'action'=>'AdminIndex@store']); ?>

        <div class="form-group">
          <label>Add Question</label>
          <input type="text" name="question" placeholder="Add Question" required="required" class="form-control">
        </div>
        <div class="form-group">
          <center><button class="btn btn-success btn-sm">Submit</button></center>
        </div>
        <?php echo Form::close(); ?>        
      </div>


    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/admin/question.blade.php ENDPATH**/ ?>