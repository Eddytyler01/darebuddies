<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?></title>
    <style type="text/css">
        .result_link
        {
            text-align:left!important;
        }
    </style>



<?php $__env->startSection('content'); ?>

<div class="container first_half">
    <div class="" id="select">
        <h1>Choose your option! </h1>
        <div class="main_box">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="text-primary text-center">Already Made Questions</h2>
                    <a href="javascript:void(0)" onclick="gogreen()" style="width:100%;" class="btn btn-primary">Get Started!</a><br/><br/>
                </div>
                <div class="col-md-6">
                    <h2 class="text-primary text-center">Make Your Own Questions</h2>
                    <a href="<?php echo e(url('/make-question')); ?>" style="width:100%;" class="btn btn-primary">Get Started!</a><br/><br/>
                </div>
            </div>          
        </div>

        
       
    </div>
    <div class="" id="questions">
        <h1>Your Diary will have these questions! </h1>
        <div class="main_box">
            <?php if(count($question) == 0): ?>
                <div class="result_link text-danger">
                    <center><strong>This diary is not ready! please check after sometime!!</strong></center>
                </div> 
                <br/>
                <center><a href="javascript:void(0)" class="btn btn-success" onclick="goback()"><i class="fa fa-arrow-left"></i> Go Back</a></center>
            <?php else: ?>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="result_link">
                    <?php echo e($questions->question); ?>

                </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <br/>
                <?php echo Form::open(['method'=>'POST', 'url'=>'/create-record']); ?>

                <input type="hidden" name="user_id" value="<?php echo e($user->user_id); ?>">
                <center>
                    <a href="javascript:void(0)" class="btn btn-success" onclick="goback()"><i class="fa fa-arrow-left"></i> Go Back</a>
                    <button class="btn btn-primary">Proceed</button>
                </center>
                <?php echo Form::close(); ?>

            <?php endif; ?>
        </div>

        
       
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
    function gogreen() 
    {
        $('#select').hide();
        $('#questions').show();
    }
    function goback() 
    {
        $('#questions').hide();
        $('#select').show();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/option.blade.php ENDPATH**/ ?>