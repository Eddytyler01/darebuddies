<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?></title>
    <style type="text/css">
        .result_link
        {
            text-align:left!important;
        }
    </style>


<?php $__env->startSection('content'); ?>
<?php 
use Illuminate\Support\Facades\Crypt;
?>

<?php if(isset($make)): ?>
<div class="container first_half">
    
    <?php if(Session::has('insert')): ?>
        <div class="alert alert-success text-center">
            <strong> <?php echo e(session('insert')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="">
        <h1>Create Questions </h1>
        <div class="main_box">
            <h2 class="text-primary"> <?php if($make == 2): ?> Objective Questions <?php else: ?>  True / False Questions <?php endif; ?> </h2><br/>
            <div class="row">
                <div class="col-md-12">
                    <?php if(count($question) >= 10): ?>
                    <strong class="text-center text-danger">Can't add more than 10 questions!!</strong>
                    <?php else: ?>
                    <?php echo Form::open(['method'=>'POST', 'url'=>'/create-record']); ?>

                        <div class="form-group">
                            <label>Enter Question</label>
                            <input type="text" name="question" class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your question" required="required" value="<?php echo e(old('question')); ?>">
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($make == 2): ?>
                        <div class="row">
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label>Option A</label>
                                    <input type="text" name="a1" class="form-control <?php $__errorArgs = ['a1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Option A" required="required" value="<?php echo e(old('a1')); ?>">
                                    <?php $__errorArgs = ['a1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label>Option B</label>
                                    <input type="text" name="a2" class="form-control <?php $__errorArgs = ['a2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Option B" required="required" value="<?php echo e(old('a2')); ?>">
                                    <?php $__errorArgs = ['a2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <div class="form-group">
                                    <label>Option C</label>
                                    <input type="text" name="a3" class="form-control <?php $__errorArgs = ['a3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Option C" required="required" value="<?php echo e(old('a3')); ?>">
                                    <?php $__errorArgs = ['a3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-6">
                                <div class="form-group">
                                    <label>Option D</label>
                                    <input type="text" name="a4" class="form-control <?php $__errorArgs = ['a4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Option D" required="required" value="<?php echo e(old('a4')); ?>">
                                    <?php $__errorArgs = ['a4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Correct Answer</label>
                                    <select class="form-control" required="required" name="correct">
                                        <option value="">Select Correct Answer</option>
                                        <option value="A">Option A</option>
                                        <option value="B">Option B</option>
                                        <option value="C">Option C</option>
                                        <option value="D">Option D</option>
                                    </select>
                                    <?php $__errorArgs = ['a4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        
                        
                        <?php else: ?>
                        <div class="form-group">
                            <label>Select Correct Answer</label>
                            <select class="form-control" name="correct" required="required">
                                <option value="">Select Correct Answer</option>
                                <option value="True">True</option>
                                <option value="False">False</option>
                            </select>
                            <input type="hidden" name="trfa" value="0">
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <center><button class="btn btn-success">Submit</button></center>
                        </div>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(count($question) != 0): ?>
        <div class="main_box">
            <h2 class="text-primary"> Your Questions <small class="text-danger"><strong>Complete 10 questions to proceed!</strong></small></h2>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="result_link">
                <strong><?php echo e($i); ?></strong>. <?php echo e($ques->question); ?><br/>
                <small class="text-success"><strong>Ans</strong>. <?php echo e($ques->correct); ?></small>
                <a href="<?php echo e(url('/delete-question', Crypt::encrypt($ques->id))); ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger btn-sm pull-right" style="margin-top:-15px;"><i class="fa fa-trash"></i></a>
            </div>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($question) >= 10): ?>
            <br/>
            <?php echo Form::open(['method'=>'POST', 'url'=>'/create-record']); ?>

                <input type="hidden" name="user_id" value="0">
                <center>
                    <button class="btn btn-primary">Proceed</button>
                </center>
            <?php echo Form::close(); ?>

            <?php endif; ?>
        </div>
        <?php endif; ?>
        
    </div>
</div>
<?php else: ?>
<div class="container first_half">
    <?php if(Session::has('danger')): ?>
        <div class="alert alert-danger text-center">
            <strong> <?php echo e(session('danger')); ?></strong>
        </div>
    <?php endif; ?>
    <div class="">
        <h1>Make your own Questions </h1>
        <div class="main_box">
            <h2 class="text-primary">Question Type:</h2><br/>
            <div class="row">
                <div class="col-xs-6">
                    <center>
                        <a href="<?php echo e(url('/create-question', Crypt::encrypt(2))); ?>">
                            <img src="<?php echo e(url('/')); ?>/images/list.png" class="img-responsive" alt="Optional">
                            <h3>Objective</h3>
                        </a>
                    </center>
                </div>
                <div class="col-xs-6">
                    <center>
                        <a href="<?php echo e(url('/create-question', Crypt::encrypt(3))); ?>">
                            <img src="<?php echo e(url('/')); ?>/images/trfa.png" style="width:135px;" class="img-responsive" alt="True/False">
                            <h3>True/False</h3>
                        </a>
                    </center>
                </div>
            </div>
        </div>
        
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/make.blade.php ENDPATH**/ ?>