<!DOCTYPE html>
<html>
<head>
    <title>I want your answer let see how much you know about me? | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?></title>
    <meta name="description"  content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta name="keywords"  content="<?php echo e($data->site_keywords ? $data->site_keywords : 'Enter keywords'); ?>" />
    <link rel="canonical" href="<?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="I want your answer let ses how much you know about me? | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:description" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta property="og:url" content="<?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>" />
    <meta property="og:site_name" content="I want your answer let ses how much you know about me? | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta name="twitter:text:title" content="I want your answer let ses how much you know about me? | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta name="twitter:card" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />



<?php $__env->startSection('content'); ?>

<div class="container first_half">
    <div class="">
        <h1>Get ready to fill <?php echo e($user->name); ?>'s Diary </h1>
        
        <div class="main_box">
            <?php echo Form::open(['method'=>'POST', 'url'=>'/create-record']); ?>

            <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <div class="form-group">
                    <input type="text" name="player" class="form-control" required="required" placeholder="Enter your name ( Ex: Esha )">
                </div>
                <center><button class="btn btn-primary btn-sm"><i class="fa fa-paper-plane fa-fw"></i> Start</button></center>
            <?php echo Form::close(); ?>

        </div>
        <div class="main_box">
            <h2 class="text-primary">Instructions:</h2>
            <ul>
                <li>Enter your name.</li>
                <li>Write not more than 10 honest answers about your friend. </li>
                <li>View your answers at the Dareboard. </li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/match.blade.php ENDPATH**/ ?>