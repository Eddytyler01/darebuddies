

<?php $__env->startSection('content'); ?>

	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Custom Footer Ad</li>
        </ol>

		<a href="<?php echo e(route('admin.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		<?php if(Session::has('insert')): ?>
            <div class="alert alert-success">
                <strong> <?php echo e(session('insert')); ?></strong>
            </div><br/>
            <?php else: ?>
            <div class="alert alert-info">
                <strong> Note:</strong><br/>
                <strong>Image Width:</strong> 400 pixels<br/>
                <strong>Image Height:</strong> 350 pixels
            </div><br/>
        <?php endif; ?>

		<?php echo Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1'], 'files'=>true]); ?>

			<div class="form-group">
        <label>Select File</label>
        <input type="file" name="photo" class="form-control <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				<?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
      <?php if($data->footer_custom_ad != null): ?>
      <div class="form-group">
        <img src="<?php echo e(url('/')); ?>/images/<?php echo e($data->footer_custom_ad); ?>" class="img-responsive" style="width:200px;height:200px;">
      </div>
      <?php endif; ?>
      <div class="form-group">
        <label>Ad Link</label>
        <input type="text" name="ad_link" required="required" class="form-control <?php $__errorArgs = ['ad_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ad Link" value="<?php echo e($data->footer_custom_link ? $data->footer_custom_link : old('ad_link')); ?>">
        <?php $__errorArgs = ['ad_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
          </span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/admin/custom.blade.php ENDPATH**/ ?>