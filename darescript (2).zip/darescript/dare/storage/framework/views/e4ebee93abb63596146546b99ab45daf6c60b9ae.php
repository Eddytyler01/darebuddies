<!DOCTYPE html>
<html>
<head>
    <title>Dare Result | <?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description"  content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta name="keywords"  content="<?php echo e($data->site_keywords ? $data->site_keywords : 'Enter keywords'); ?>" />
    <link rel="canonical" href="<?php echo e(url('/')); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:description" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <meta property="og:url" content="<?php echo e(url('/')); ?>" />
    <meta property="og:site_name" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta property="og:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta property="og:locale" content="en_US" />
    <meta name="twitter:image" content="<?php echo e(url('/')); ?>/images/<?php echo e($data->og_image ? $data->og_image : ''); ?>" />
    <meta name="twitter:text:title" content="<?php echo e($data->site_title ? $data->site_title : 'JJ Dare'); ?>" />
    <meta name="twitter:card" content="<?php echo e($data->site_description ? $data->site_description : 'Enter Description'); ?>" />
    <style type="text/css">
      .result_link
      {
        text-align:left!important;
      }
      #copy_text
      {
        overflow:hidden;
      }
    </style>


<?php $__env->startSection('content'); ?>
<?php 
use App\Answer;
?>
<div class="container first_half">
    <div class="">
        <h1><?php echo e($user->name); ?> Your Diary is Ready! </h1>
        <div class="main_box">
            <h2 class="text-primary text-center"> 
                Now share the link with your friends!
                <br/>
                Let them answer all your questions 
            </h2>
            <div class="result_link" id="copy_text" style="text-align:center!important;">
                <?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>

            </div><br/>
            <a href="javascript:void(0)" onclick="copy_text()" class="btn btn-primary" style="width:100%;"><i class="fa fa-copy fa-fw"></i> Copy Link</a>
        </div>
        <br/>
        <a href="whatsapp://send?text=*10 Questions About <?php echo e($user->name); ?>*%0A%0A*I Want Your Answers*🤗🙏%0A%0AThis will help me to know what you think about me%0A%0AClick Now👇%0A%0A<?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>" class="border whatsapp">
            <i class="fa fa-whatsapp fa-fw"></i> Whatsapp Status
        </a>
        <div class="row">
            <div class="col-xs-6" style="padding-right:6px;">
                <a href="https://www.facebook.com/sharer/sharer.php?kid_directed_site=0&u=<?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>%2F&display=popup&ref=plugin&src=share_button" class="border facebook">
                    <i class="fa fa-facebook fa-fw"></i> Facebook
                </a>
            </div>
            <div class="col-xs-6" style="padding-left:6px;">
                <a href="https://twitter.com/intent/tweet?text=Title&url=<?php echo e(url('/')); ?>/match/<?php echo e($user->user_id); ?>%2F" class="border twitter">
                    <i class="fa fa-twitter fa-fw"></i> Twitter
                </a>
            </div>
        </div>
        <h1>Dareboard of <?php echo e($user->name); ?>  </h1>
        <div class="main_box">
           <div class="table-responsive">
            <?php if(count($dare) == 0): ?>
            <center>No Record Found!</center>
            <?php else: ?>
            <?php if($user->type == 1): ?>
               <table class="table table-striped table-bordered">
                   <thead>
                       <tr>
                        <th style="width:80px;">S.No</th>
                           <th>Name</th>
                           <th style="width:200px;">Answers</th>
                           <th style="width:200px;">Operation</th>
                       </tr>
                   </thead>
                   <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $dare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dares): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                          <td><?php echo e($i); ?></td>
                           <td><?php echo e($dares->name); ?></td>
                           <td><a href="" data-toggle="modal" data-target="#myModal<?php echo e($i); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a></td>
                           <td>
                               <?php echo Form::open(['method'=>'GET', 'url'=>['delete', $dares->id], 'onsubmit'=>'return confirm("Are You Sure?");']); ?>

                                <button class="btn btn-danger btn-sm"><i class="fa fa-trash fa-fw"></i></button>
                               <?php echo Form::close(); ?>

                           </td>
                       </tr>
                       <div class="modal" id="myModal<?php echo e($i); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><?php echo e($dares->name); ?>'s answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          <?php $ie = 1; $ans = Answer::where('user_id', '=', $dares->id)->orderBy('id', 'ASC')->get(); ?>
          <?php $__currentLoopData = $ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ansa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="result_link">
              <strong><?php echo e($ie); ?></strong>. <?php echo e($ansa->question->question); ?><br/>
              <small><strong class="text-success">Ans</strong>. <?php echo e($ansa->ans_given); ?></small>
          </div>
          <?php $ie++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                       <?php $i++; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
               </table>
               <?php else: ?>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th style="width:80px;">S.No</th>
                      <th>Name</th>
                      <th style="width:200px;">Score</th>
                      <th style="width:200px;">Answers</th>
                      <th style="width:200px;">Operation</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                      <?php $i = 1; ?>
                    <?php $__currentLoopData = $dare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dares): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($dares->name); ?></td>
                        <td><?php echo e($dares->result); ?> / 10</td>
                        <td><a href="" data-toggle="modal" data-target="#myModal<?php echo e($i); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye fa-fw"></i> View</a></td>
                        <td><?php echo Form::open(['method'=>'GET', 'url'=>['delete', $dares->id], 'onsubmit'=>'return confirm("Are You Sure?");']); ?>

                                <button class="btn btn-danger btn-sm"><i class="fa fa-trash fa-fw"></i></button>
                               <?php echo Form::close(); ?></td>
                      </tr>
                      <div class="modal" id="myModal<?php echo e($i); ?>">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><?php echo e($dares->name); ?>'s answers</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="main_box">
          <?php $ie = 1; $ans = Answer::where('user_id', '=', $dares->id)->orderBy('id', 'ASC')->get(); ?>
          <?php $__currentLoopData = $ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ansa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="result_link">
              <strong><?php echo e($ie); ?></strong>. <?php echo e($ansa->question->question); ?><br/>
              <small><strong class="text-success">Correct Ans</strong>. <?php echo e($ansa->question->correct); ?></small> | <small><strong class="text-success">You Given</strong>. <?php echo e($ansa->ans_given); ?></small>
          </div>
          <?php $ie++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                    <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </tbody>
                </table>
               <?php endif; ?>
               <?php endif; ?>
           </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
    function copy_text() 
    {
        let shareLink = document.getElementById("copy_text");
        var range = document.createRange();
        range.selectNodeContents(shareLink);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('copy');
        alert('Copied!!');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/result.blade.php ENDPATH**/ ?>