

<?php $__env->startSection('content'); ?>
<style type="text/css">
  #mceu_44
  {
    display:none!important;
  }
</style>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>tinymce.init({ selector:'#editer',
    plugins: [
        "advlist autolink lists charmap print preview hr pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime nonbreaking save contextmenu directionality",
        "paste textcolor colorpicker"
    ],
    toolbar1: "undo redo | styleselect fontselect | fontsizeselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent",
    toolbar2: "link | colorpicker forecolor backcolor | preview ",

 });

</script>
	<div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Contact-Us Page</li>
        </ol>

		<a href="<?php echo e(route('admin.index')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-arrow-left"></i> Go Back</a>
		<br/><br/>
		<?php if(Session::has('insert')): ?>
            <div class="alert alert-success">
                <strong> <?php echo e(session('insert')); ?></strong>
            </div><br/>
        <?php endif; ?>

		<?php echo Form::model($data, ['method'=>'PATCH', 'action'=>['AdminIndex@update', '1']]); ?>

			<div class="form-group">
				<label>Contact-Us Page</label>
				<textarea rows="6" id="editer" style="min-height:500px;" class="form-control <?php $__errorArgs = ['contact_us'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="contact_us" placeholder="Code here..."><?php echo e($data->contant_us ? $data->contant_us : old('contact_us')); ?></textarea>
				<?php $__errorArgs = ['contact_us'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<center><button class="btn btn-success btn-sm">Submit</button></center>
			</div>
		<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dare\resources\views/admin/contact.blade.php ENDPATH**/ ?>