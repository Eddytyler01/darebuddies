-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 10, 2020 at 11:43 AM
-- Server version: 5.7.24
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dare`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ques_id` int(10) UNSIGNED NOT NULL,
  `ans_given` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `answers_user_id_index` (`user_id`),
  KEY `answers_ques_id_index` (`ques_id`)
) ENGINE=MyISAM AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `header_ad` text COLLATE utf8mb4_unicode_ci,
  `footer_ad` text COLLATE utf8mb4_unicode_ci,
  `footer_custom_ad` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_custom_link` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_code` text COLLATE utf8mb4_unicode_ci,
  `site_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_keywords` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about_us` text COLLATE utf8mb4_unicode_ci,
  `footer` text COLLATE utf8mb4_unicode_ci,
  `contant_us` text COLLATE utf8mb4_unicode_ci,
  `policy` text COLLATE utf8mb4_unicode_ci,
  `tc` text COLLATE utf8mb4_unicode_ci,
  `verification` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `header_ad`, `footer_ad`, `footer_custom_ad`, `footer_custom_link`, `google_code`, `site_name`, `site_title`, `site_description`, `site_keywords`, `og_image`, `about_us`, `footer`, `contant_us`, `policy`, `tc`, `verification`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-26 15:27:51');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_03_31_181648_create_roles_table', 1),
(5, '2020_03_31_183839_create_data_table', 2),
(6, '2020_04_01_162912_create_questions_table', 3),
(7, '2020_04_02_080510_create_answers_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(12) NOT NULL DEFAULT '0',
  `a1` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `a2` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `a3` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `a4` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `questions_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `question`, `status`, `a1`, `a2`, `a3`, `a4`, `correct`, `created_at`, `updated_at`) VALUES
(1, 1, 'What is your favorite nickname for me?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:15:10', '2020-04-02 02:07:09'),
(2, 1, 'What is your relation with me?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:20:33', '2020-04-02 02:07:10'),
(3, 1, 'What is your favorite memory with me?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:20:48', '2020-04-02 02:07:11'),
(4, 1, 'If you could add one thing in my life, what would it be?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:21:08', '2020-04-02 02:07:12'),
(5, 1, 'Which physical feature of mine do you like the most?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:23:07', '2020-04-02 02:07:14'),
(6, 1, 'According to you, what color best suits me the most?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:23:23', '2020-04-02 02:07:15'),
(7, 1, 'What special gift would you give to me?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:23:36', '2020-04-02 02:07:16'),
(8, 1, 'Do you trust me?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:23:45', '2020-04-02 02:07:17'),
(9, 1, 'If you could change one thing about me, what would it be?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:24:07', '2020-04-02 02:07:19'),
(10, 1, 'Is there a secret you want to tell me?', 0, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:24:29', '2020-04-02 01:42:10'),
(11, 1, 'Would u date me? If yes what\'s stopping u?', 1, NULL, NULL, NULL, NULL, NULL, '2020-04-02 01:41:36', '2020-04-02 02:07:22');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2020-03-30 18:30:00', '2020-03-30 18:30:00'),
(2, 'User', '2020-03-31 18:30:00', '2020-03-31 18:30:00'),
(3, 'Player', '2020-04-01 18:30:00', '2020-04-01 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `status` int(12) NOT NULL DEFAULT '0',
  `type` int(12) DEFAULT NULL,
  `user_id` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` int(12) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_index` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `status`, `type`, `user_id`, `role_id`, `name`, `email`, `result`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, NULL, NULL, 1, 'Dare4you', 'admin@admin.com', NULL, NULL, '$2y$10$ohTMPP8PZXx6x2TqrE9W0uf2C0zSZWFZzOu4ZvyH6RQfVbekSiFQa', NULL, '2020-03-31 18:30:00', '2020-07-09 12:36:13');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
